"""Terminal interface for Citra."""

